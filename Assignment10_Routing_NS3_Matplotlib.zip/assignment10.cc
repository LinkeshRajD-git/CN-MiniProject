#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/aodv-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <algorithm>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("Assignment10RoutingComparison");

static uint64_t g_rxBytes = 0;
static uint64_t g_rxPackets = 0;
static double g_delaySum = 0.0;
static uint64_t g_txPackets = 0;
static uint64_t g_prevRxPackets = 0;
static uint64_t g_routeUpdateProxy = 0;
static std::ofstream g_timeseries;

static void RxTrace(Ptr<const Packet> packet, const Address &address)
{
    g_rxBytes += packet->GetSize();
    g_rxPackets++;
}

static void Sample(double interval)
{
    uint64_t currentRx = g_rxPackets;
    // A receive-count change is only a reachability/activity proxy, not a routing-table dump.
    if ((currentRx > 0) != (g_prevRxPackets > 0)) g_routeUpdateProxy++;
    g_timeseries << std::fixed << std::setprecision(6)
                 << Simulator::Now().GetSeconds() << ","
                 << g_rxPackets << "," << g_rxBytes << ","
                 << g_routeUpdateProxy << "\n";
    g_prevRxPackets = currentRx;
    if (Simulator::Now().GetSeconds() + interval <= 19.99)
        Simulator::Schedule(Seconds(interval), &Sample, interval);
}

int main(int argc, char *argv[])
{
    std::string routing = "Global";
    std::string condition = "normal";
    std::string output = "routing_results.csv";
    std::string timeseries = "routing_timeseries.csv";
    double simTime = 20.0;
    double appStart = 1.0;
    double appStop = 19.0;
    uint32_t packetSize = 512;
    std::string dataRate = "256Kbps";
    uint32_t extraFlows = 0;
    double failureTime = 10.0;
    bool failLink = false;

    CommandLine cmd(__FILE__);
    cmd.AddValue("routing", "Routing mode: Global or AODV (Global is a static/global-routing baseline)", routing);
    cmd.AddValue("condition", "normal, congestion, or failure", condition);
    cmd.AddValue("output", "Summary CSV output path", output);
    cmd.AddValue("timeseries", "Per-second CSV output path", timeseries);
    cmd.AddValue("simTime", "Simulation duration in seconds", simTime);
    cmd.AddValue("dataRate", "CBR application rate per flow", dataRate);
    cmd.AddValue("extraFlows", "Number of extra simultaneous UDP flows", extraFlows);
    cmd.AddValue("failureTime", "Time to disable one link in failure condition", failureTime);
    cmd.Parse(argc, argv);

    if (routing != "Global" && routing != "AODV")
    {
        NS_LOG_UNCOND("Unsupported routing value. Use Global or AODV. See README for RIP/OSPF limitations.");
        return 1;
    }
    if (condition == "congestion") extraFlows = std::max<uint32_t>(extraFlows, 4);
    if (condition == "failure") failLink = true;

    // Four routers in a diamond: R0-R1-R3 and R0-R2-R3, plus a cross-link R1-R2.
    NodeContainer routers;
    routers.Create(4);
    NodeContainer hosts;
    hosts.Create(4);

    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("5Mbps"));
    p2p.SetChannelAttribute("Delay", StringValue("5ms"));
    p2p.SetQueue("ns3::DropTailQueue", "MaxSize", StringValue("50p"));

    NetDeviceContainer h0r0 = p2p.Install(NodeContainer(hosts.Get(0), routers.Get(0)));
    NetDeviceContainer h1r1 = p2p.Install(NodeContainer(hosts.Get(1), routers.Get(1)));
    NetDeviceContainer h2r2 = p2p.Install(NodeContainer(hosts.Get(2), routers.Get(2)));
    NetDeviceContainer h3r3 = p2p.Install(NodeContainer(hosts.Get(3), routers.Get(3)));
    NetDeviceContainer r0r1 = p2p.Install(NodeContainer(routers.Get(0), routers.Get(1)));
    NetDeviceContainer r0r2 = p2p.Install(NodeContainer(routers.Get(0), routers.Get(2)));
    NetDeviceContainer r1r3 = p2p.Install(NodeContainer(routers.Get(1), routers.Get(3)));
    NetDeviceContainer r2r3 = p2p.Install(NodeContainer(routers.Get(2), routers.Get(3)));
    NetDeviceContainer r1r2 = p2p.Install(NodeContainer(routers.Get(1), routers.Get(2)));

    NodeContainer all;
    all.Add(hosts);
    all.Add(routers);

    InternetStackHelper internet;
    if (routing == "AODV")
    {
        AodvHelper aodv;
        internet.SetRoutingHelper(aodv);
    }
    else
    {
        Ipv4GlobalRoutingHelper global;
        internet.SetRoutingHelper(global);
    }
    internet.Install(all);

    Ipv4AddressHelper address;
    address.SetBase("10.0.1.0", "255.255.255.0"); address.Assign(h0r0);
    address.SetBase("10.0.2.0", "255.255.255.0"); address.Assign(h1r1);
    address.SetBase("10.0.3.0", "255.255.255.0"); address.Assign(h2r2);
    address.SetBase("10.0.4.0", "255.255.255.0"); address.Assign(h3r3);
    address.SetBase("10.0.5.0", "255.255.255.0"); address.Assign(r0r1);
    address.SetBase("10.0.6.0", "255.255.255.0"); address.Assign(r0r2);
    address.SetBase("10.0.7.0", "255.255.255.0"); address.Assign(r1r3);
    address.SetBase("10.0.8.0", "255.255.255.0"); address.Assign(r2r3);
    address.SetBase("10.0.9.0", "255.255.255.0"); address.Assign(r1r2);

    if (routing == "Global")
        Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    // UDP CBR flows: H0->H3 and H1->H2. Congestion condition adds H0/H1/H2/H3 cross-flows.
    uint16_t basePort = 9000;
    ApplicationContainer sinks;
    for (uint32_t i = 0; i < 4; ++i)
    {
        UdpServerHelper server(basePort + i);
        sinks.Add(server.Install(hosts.Get(i)));
    }
    sinks.Start(Seconds(0.5));
    sinks.Stop(Seconds(appStop));

    struct FlowSpec { uint32_t src; uint32_t dst; uint16_t port; };
    std::vector<FlowSpec> flows = {{0,3,basePort+3}, {1,2,basePort+2}};
    if (extraFlows >= 1) flows.push_back({0,2,basePort+2});
    if (extraFlows >= 2) flows.push_back({1,3,basePort+3});
    if (extraFlows >= 3) flows.push_back({2,0,basePort+0});
    if (extraFlows >= 4) flows.push_back({3,1,basePort+1});

    for (const auto &f : flows)
    {
        UdpClientHelper client(Ipv4Address("10.0.4.2"), f.port);
        // Replace destination based on selected receiver host.
        Ptr<Ipv4> dstIpv4 = hosts.Get(f.dst)->GetObject<Ipv4>();
        Ipv4Address dstAddress = dstIpv4->GetAddress(1, 0).GetLocal();
        client.SetAttribute("RemoteAddress", AddressValue(Address(dstAddress)));
        client.SetAttribute("MaxPackets", UintegerValue(1000000));
        client.SetAttribute("Interval", TimeValue(Seconds(512.0 * 8.0 / (std::stod(dataRate.substr(0, dataRate.find("K")))*1000.0))));
        client.SetAttribute("PacketSize", UintegerValue(packetSize));
        client.SetAttribute("RemotePort", UintegerValue(f.port));
        ApplicationContainer app = client.Install(hosts.Get(f.src));
        app.Start(Seconds(appStart + 0.1 * f.src));
        app.Stop(Seconds(appStop));
    }

    if (failLink)
    {
        // Disable the R1-R3 link; the diamond provides R1-R2-R3 as an alternate path.
        Ptr<PointToPointNetDevice> dev = DynamicCast<PointToPointNetDevice>(r1r3.Get(0));
        Ptr<PointToPointNetDevice> dev2 = DynamicCast<PointToPointNetDevice>(r1r3.Get(1));
        Simulator::Schedule(Seconds(failureTime), [dev, dev2]() {
            dev->SetLinkDown();
            dev2->SetLinkDown();
        });
    }

    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> monitor = flowHelper.InstallAll();

    g_timeseries.open(timeseries);
    g_timeseries << "time_s,rx_packets,rx_bytes,route_update_proxy\n";
    Simulator::Schedule(Seconds(1.0), &Sample, 1.0);
    Simulator::Stop(Seconds(simTime));
    Simulator::Run();

    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowHelper.GetClassifier());
    auto stats = monitor->GetFlowStats();
    uint64_t txPackets = 0, rxPackets = 0, lostPackets = 0, rxBytes = 0;
    double delaySum = 0.0;
    for (const auto &entry : stats)
    {
        const auto &st = entry.second;
        txPackets += st.txPackets;
        rxPackets += st.rxPackets;
        lostPackets += st.lostPackets;
        rxBytes += st.rxBytes;
        delaySum += st.delaySum.GetSeconds();
    }
    double pdr = txPackets ? 100.0 * rxPackets / txPackets : 0.0;
    double meanDelayMs = rxPackets ? 1000.0 * delaySum / rxPackets : 0.0;
    double throughputKbps = (simTime > appStart) ? (rxBytes * 8.0 / (simTime - appStart) / 1000.0) : 0.0;

    bool exists = std::ifstream(output).good();
    std::ofstream out(output, std::ios::app);
    if (!exists) out << "routing,condition,tx_packets,rx_packets,lost_packets,pdr_percent,mean_delay_ms,throughput_kbps,route_update_proxy\n";
    out << routing << "," << condition << "," << txPackets << "," << rxPackets << ","
        << lostPackets << "," << std::fixed << std::setprecision(4) << pdr << ","
        << meanDelayMs << "," << throughputKbps << "," << g_routeUpdateProxy << "\n";

    monitor->SerializeToXmlFile("routing-flowmon.xml", true, true);
    g_timeseries.close();
    Simulator::Destroy();
    return 0;
}
