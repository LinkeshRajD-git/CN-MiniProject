# Assignment 10 — Comparative Evaluation of Routing Protocols Using NS-3

## What this package contains
- `assignment10.cc` — NS-3 C++ simulation for a four-router diamond topology with four end hosts, UDP/CBR flows, congestion and link-failure scenarios.
- `assignment10_analysis.ipynb` — pandas/Matplotlib notebook that creates the three required graphs.
- `README.md` — setup, run commands, metrics, and important protocol limitations.

## Important protocol-implementation note
The assignment asks for RIP, OSPF, and AODV. A standard NS-3.42 installation does **not** provide a ready-to-use IPv4 RIP or OSPF implementation comparable to a full router simulator. This starter package therefore uses:
- `AODV`: NS-3's AODV routing module.
- `Global`: NS-3 IPv4 global-routing baseline (routes are populated centrally).

**Do not report the `Global` results as actual RIP or OSPF results.** Global routing is not RIP or OSPF. To make a valid three-protocol comparison, implement/import a compatible RIP and OSPF module, or use a simulator with those protocol implementations. The notebook labels the Global baseline honestly.

The `route_update_proxy` field is deliberately only a coarse reachability/activity proxy; it is **not** a count of actual routing-table updates. The generic FlowMonitor API does not expose comparable routing-table-update counters across these protocols. For the assignment's routing-table-updates graph, either instrument each protocol's route-change callbacks or label the proxy clearly and discuss this limitation.

The link failure uses `PointToPointNetDevice::SetLinkDown()` on the R1-R3 link. Route reconvergence behavior depends on the routing protocol and NS-3 build. Validate the scenario on your installed version before submitting.

## Topology
Four routers are arranged as a diamond:
- R0–R1–R3 and R0–R2–R3
- R1–R2 cross-link
- One host attached to each router
- CBR/UDP flows across the topology

The failure scenario disables R1–R3, leaving the alternate R1–R2–R3 route.

## Install NS-3 (example)
Use your existing NS-3 installation. These commands assume `~/ns-3.42`:
```bash
cp assignment10.cc ~/ns-3.42/scratch/
cd ~/ns-3.42
./ns3 build
```

If compilation fails, first check the exact API names available in your NS-3 version and the AODV module build configuration.

## Run scenarios
Run from the NS-3 root directory. Each run appends a row to `routing_results.csv`; delete that CSV before a clean experiment.

```bash
# AODV: normal, congestion, link failure
./ns3 run "scratch/assignment10 --routing=AODV --condition=normal --output=routing_results.csv --timeseries=aodv_normal_timeseries.csv"
./ns3 run "scratch/assignment10 --routing=AODV --condition=congestion --extraFlows=4 --output=routing_results.csv --timeseries=aodv_congestion_timeseries.csv"
./ns3 run "scratch/assignment10 --routing=AODV --condition=failure --failureTime=10 --output=routing_results.csv --timeseries=aodv_failure_timeseries.csv"

# Global-routing baseline: normal, congestion, link failure
./ns3 run "scratch/assignment10 --routing=Global --condition=normal --output=routing_results.csv --timeseries=global_normal_timeseries.csv"
./ns3 run "scratch/assignment10 --routing=Global --condition=congestion --extraFlows=4 --output=routing_results.csv --timeseries=global_congestion_timeseries.csv"
./ns3 run "scratch/assignment10 --routing=Global --condition=failure --failureTime=10 --output=routing_results.csv --timeseries=global_failure_timeseries.csv"
```

The program writes `routing-flowmon.xml` (overwritten each run). Copy/rename it after each run if you need to preserve individual FlowMonitor traces.

## Generate graphs
Install Python dependencies:
```bash
python3 -m pip install pandas matplotlib jupyter
jupyter notebook assignment10_analysis.ipynb
```
Place `routing_results.csv` beside the notebook and run all cells. It plots:
1. PDR vs network condition
2. End-to-end delay vs network condition
3. Routing-update proxy vs network condition

The notebook supports `Global` and `AODV` labels as they appear in the CSV. It does not fabricate RIP/OSPF data.

## Metrics
- **PDR (%)** = received packets / transmitted packets × 100.
- **Mean end-to-end delay (ms)** = FlowMonitor delay sum / received packets.
- **Throughput (kbps)** = received bytes × 8 / measurement interval.
- **Routing updates**: actual updates require protocol-specific trace instrumentation. `route_update_proxy` is not an actual routing-table-update count.

## Submission checklist
1. Compile and run the source in your exact NS-3 version.
2. Confirm that each scenario produces plausible CSV values.
3. For a strict RIP/OSPF/AODV comparison, add genuine RIP and OSPF implementations and instrument route changes.
4. Include the generated plots and discuss normal, congestion, and link-failure behavior without describing the Global baseline as RIP/OSPF.
