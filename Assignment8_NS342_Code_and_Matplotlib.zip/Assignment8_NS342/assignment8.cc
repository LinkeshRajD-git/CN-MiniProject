// Assignment 8: Simulation and Performance Analysis of TCP and UDP Traffic Using NS-3.42
// Topology:
// n0 -- r1 ===== r2 -- n3 : TCP n0 -> n3
// n1 -- r1 ===== r2 -- n2 : UDP n1 -> n2
//
// Defaults: access links 10Mbps/2ms; bottleneck 2Mbps/10ms;
// DropTail queue 50 packets; sim 20s; TCP SendSize 1024 bytes;
// UDP packet 512 bytes at 1Mbps.
//
// Run from NS-3.42 root:
// ./ns3 run "scratch/assignment8 --bottleneckRate=5Mbps --bottleneckDelay=10ms --queuePackets=50 --udpRate=1Mbps"

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

using namespace ns3;

static double ParseRateBps(const std::string& rate)
{
    if (rate.find("Mbps") != std::string::npos)
        return std::stod(rate.substr(0, rate.find("Mbps"))) * 1e6;
    if (rate.find("Kbps") != std::string::npos)
        return std::stod(rate.substr(0, rate.find("Kbps"))) * 1e3;
    if (rate.find("bps") != std::string::npos)
        return std::stod(rate.substr(0, rate.find("bps")));
    NS_FATAL_ERROR("Rate must look like 500Kbps, 1Mbps, or 100000bps");
    return 1e6;
}

int main(int argc, char* argv[])
{
    std::string accessRate = "10Mbps";
    std::string accessDelay = "2ms";
    std::string bottleneckRate = "2Mbps";
    std::string bottleneckDelay = "10ms";
    std::string udpRate = "1Mbps";
    std::string csvFile = "assignment8_results.csv";
    std::string pcapPrefix = "assignment8";
    uint32_t queuePackets = 50;
    uint32_t tcpPacketSize = 1024;
    uint32_t udpPacketSize = 512;
    double simulationTime = 20.0;

    CommandLine cmd(__FILE__);
    cmd.AddValue("accessRate", "Access link data rate", accessRate);
    cmd.AddValue("accessDelay", "Access link delay", accessDelay);
    cmd.AddValue("bottleneckRate", "Bottleneck data rate", bottleneckRate);
    cmd.AddValue("bottleneckDelay", "Bottleneck propagation delay", bottleneckDelay);
    cmd.AddValue("udpRate", "UDP offered rate (e.g. 500Kbps, 1Mbps)", udpRate);
    cmd.AddValue("queuePackets", "DropTail queue capacity in packets", queuePackets);
    cmd.AddValue("tcpPacketSize", "TCP BulkSend write size in bytes", tcpPacketSize);
    cmd.AddValue("udpPacketSize", "UDP datagram size in bytes", udpPacketSize);
    cmd.AddValue("simulationTime", "Simulation duration in seconds", simulationTime);
    cmd.AddValue("csv", "CSV results path", csvFile);
    cmd.AddValue("pcapPrefix", "PCAP filename prefix", pcapPrefix);
    cmd.Parse(argc, argv);

    if (queuePackets == 0 || tcpPacketSize == 0 || udpPacketSize == 0 ||
        simulationTime <= 5.0 || ParseRateBps(udpRate) <= 0.0)
    {
        NS_FATAL_ERROR("Invalid queue/packet size, duration, or UDP rate");
    }

    Ptr<Node> n0 = CreateObject<Node>();
    Ptr<Node> n1 = CreateObject<Node>();
    Ptr<Node> n2 = CreateObject<Node>();
    Ptr<Node> n3 = CreateObject<Node>();
    Ptr<Node> r1 = CreateObject<Node>();
    Ptr<Node> r2 = CreateObject<Node>();

    NodeContainer all;
    all.Add(n0); all.Add(n1); all.Add(n2); all.Add(n3); all.Add(r1); all.Add(r2);

    PointToPointHelper access;
    access.SetDeviceAttribute("DataRate", StringValue(accessRate));
    access.SetChannelAttribute("Delay", StringValue(accessDelay));
    access.SetQueue("ns3::DropTailQueue<Packet>",
                    "MaxSize", QueueSizeValue(QueueSize(std::to_string(queuePackets) + "p")));

    PointToPointHelper bottleneck;
    bottleneck.SetDeviceAttribute("DataRate", StringValue(bottleneckRate));
    bottleneck.SetChannelAttribute("Delay", StringValue(bottleneckDelay));
    bottleneck.SetQueue("ns3::DropTailQueue<Packet>",
                        "MaxSize", QueueSizeValue(QueueSize(std::to_string(queuePackets) + "p")));

    NetDeviceContainer d0r1 = access.Install(NodeContainer(n0, r1));
    NetDeviceContainer d1r1 = access.Install(NodeContainer(n1, r1));
    NetDeviceContainer dr1r2 = bottleneck.Install(NodeContainer(r1, r2));
    NetDeviceContainer dr2n2 = access.Install(NodeContainer(r2, n2));
    NetDeviceContainer dr2n3 = access.Install(NodeContainer(r2, n3));

    InternetStackHelper internet;
    internet.Install(all);

    Ipv4AddressHelper ip;
    ip.SetBase("10.0.1.0", "255.255.255.0"); Ipv4InterfaceContainer i0r1 = ip.Assign(d0r1);
    ip.SetBase("10.0.2.0", "255.255.255.0"); Ipv4InterfaceContainer i1r1 = ip.Assign(d1r1);
    ip.SetBase("10.0.3.0", "255.255.255.0"); Ipv4InterfaceContainer ir1r2 = ip.Assign(dr1r2);
    ip.SetBase("10.0.4.0", "255.255.255.0"); Ipv4InterfaceContainer ir2n2 = ip.Assign(dr2n2);
    ip.SetBase("10.0.5.0", "255.255.255.0"); Ipv4InterfaceContainer ir2n3 = ip.Assign(dr2n3);
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    const double appStart = 1.0;
    const double appStop = simulationTime - 1.0;
    const double measurementWindow = appStop - appStart;

    // TCP flow: n0 -> n3, destination port 5000.
    const uint16_t tcpPort = 5000;
    PacketSinkHelper tcpSink("ns3::TcpSocketFactory",
        InetSocketAddress(Ipv4Address::GetAny(), tcpPort));
    ApplicationContainer tcpSinkApps = tcpSink.Install(n3);
    tcpSinkApps.Start(Seconds(0.5));
    tcpSinkApps.Stop(Seconds(simulationTime));

    BulkSendHelper tcpSource("ns3::TcpSocketFactory",
        InetSocketAddress(ir2n3.GetAddress(1), tcpPort));
    tcpSource.SetAttribute("SendSize", UintegerValue(tcpPacketSize));
    tcpSource.SetAttribute("MaxBytes", UintegerValue(0));
    ApplicationContainer tcpSourceApps = tcpSource.Install(n0);
    tcpSourceApps.Start(Seconds(appStart));
    tcpSourceApps.Stop(Seconds(appStop));

    // UDP flow: n1 -> n2, destination port 6000.
    const uint16_t udpPort = 6000;
    UdpServerHelper udpSink(udpPort);
    ApplicationContainer udpSinkApps = udpSink.Install(n2);
    udpSinkApps.Start(Seconds(0.5));
    udpSinkApps.Stop(Seconds(simulationTime));

    UdpClientHelper udpSource(ir2n2.GetAddress(1), udpPort);
    udpSource.SetAttribute("PacketSize", UintegerValue(udpPacketSize));
    udpSource.SetAttribute("Interval", TimeValue(
        Seconds(static_cast<double>(udpPacketSize) * 8.0 / ParseRateBps(udpRate))));
    udpSource.SetAttribute("MaxPackets", UintegerValue(100000000));
    ApplicationContainer udpSourceApps = udpSource.Install(n1);
    udpSourceApps.Start(Seconds(appStart));
    udpSourceApps.Stop(Seconds(appStop));

    // Capture each link; output filenames use pcapPrefix.
    access.EnablePcap(pcapPrefix + "-n0-r1", d0r1, true);
    access.EnablePcap(pcapPrefix + "-n1-r1", d1r1, true);
    bottleneck.EnablePcap(pcapPrefix + "-r1-r2", dr1r2, true);
    access.EnablePcap(pcapPrefix + "-r2-n2", dr2n2, true);
    access.EnablePcap(pcapPrefix + "-r2-n3", dr2n3, true);

    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> monitor = flowHelper.InstallAll();

    Simulator::Stop(Seconds(simulationTime));
    Simulator::Run();
    monitor->CheckForLostPackets();

    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(flowHelper.GetClassifier());

    bool needsHeader = true;
    {
        std::ifstream in(csvFile);
        if (in.good() && in.peek() != std::ifstream::traits_type::eof())
            needsHeader = false;
    }
    std::ofstream csv(csvFile, std::ios::app);
    if (!csv) NS_FATAL_ERROR("Cannot open CSV file: " << csvFile);
    if (needsHeader)
        csv << "bottleneck_rate,bottleneck_delay,udp_rate,queue_packets,protocol,"
               "source_port,destination_port,tx_packets,rx_packets,tx_bytes,rx_bytes,"
               "throughput_mbps,packet_loss_pct,avg_delay_ms\n";

    std::cout << std::fixed << std::setprecision(4)
              << "\nBottleneck=" << bottleneckRate
              << ", delay=" << bottleneckDelay << ", UDP rate=" << udpRate
              << ", queue=" << queuePackets << " packets\n";

    for (const auto& item : monitor->GetFlowStats())
    {
        const Ipv4FlowClassifier::FiveTuple tuple = classifier->FindFlow(item.first);
        const FlowMonitor::FlowStats& s = item.second;
        const bool isTcp = tuple.protocol == 6 && tuple.destinationPort == tcpPort;
        const bool isUdp = tuple.protocol == 17 && tuple.destinationPort == udpPort;
        if (!isTcp && !isUdp) continue;

        const double throughput = static_cast<double>(s.rxBytes) * 8.0 /
                                  measurementWindow / 1e6;
        const double loss = s.txPackets > 0
            ? 100.0 * static_cast<double>(s.txPackets - s.rxPackets) /
                      static_cast<double>(s.txPackets) : 0.0;
        const double avgDelayMs = s.rxPackets > 0
            ? 1000.0 * s.delaySum.GetSeconds() / static_cast<double>(s.rxPackets)
            : 0.0;
        const std::string protocol = isTcp ? "TCP" : "UDP";

        std::cout << protocol << " dstPort=" << tuple.destinationPort
                  << " TX=" << s.txPackets << " RX=" << s.rxPackets
                  << " throughput=" << throughput << " Mbps"
                  << " loss=" << loss << "%"
                  << " avgDelay=" << avgDelayMs << " ms\n";

        csv << bottleneckRate << ',' << bottleneckDelay << ',' << udpRate << ','
            << queuePackets << ',' << protocol << ',' << tuple.sourcePort << ','
            << tuple.destinationPort << ',' << s.txPackets << ',' << s.rxPackets
            << ',' << s.txBytes << ',' << s.rxBytes << ',' << throughput << ','
            << loss << ',' << avgDelayMs << '\n';
    }
    csv.close();
    monitor->SerializeToXmlFile("assignment8-flowmon.xml", true, true);

    std::cout << "CSV saved to " << csvFile
              << "\nFlowMonitor XML: assignment8-flowmon.xml"
              << "\nPCAP prefix: " << pcapPrefix
              << "\nTCP retransmissions must be analysed from PCAP/Wireshark; "
                 "FlowMonitor does not directly report retransmission count.\n";

    Simulator::Destroy();
    return 0;
}
