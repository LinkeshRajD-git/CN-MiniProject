# Assignment 8 — NS-3.42 TCP/UDP Simulation + Matplotlib Notebook

## Contents
- `assignment8.cc`: NS-3 simulation with 4 end hosts, 2 routers, TCP and UDP flows, configurable bottleneck, queue and UDP rate, FlowMonitor CSV, PCAP.
- `assignment8_analysis.ipynb`: Jupyter notebook that reads actual CSV output and plots throughput, loss, delay, and a retransmission metric if you add it.
- `README.md`: commands and interpretation.

## Run in NS-3.42
Copy `assignment8.cc` into the `scratch/` directory of your NS-3.42 source tree:
```bash
cp assignment8.cc ~/ns-3.42/scratch/
cd ~/ns-3.42
./ns3 build
./ns3 run "scratch/assignment8"
```
The code is designed for the NS-3.42 API, but it must be compiled on your installation to confirm compatibility.

## Required experiment: bottleneck bandwidth
```bash
rm -f assignment8_results.csv
./ns3 run "scratch/assignment8 --bottleneckRate=2Mbps --csv=assignment8_results.csv"
./ns3 run "scratch/assignment8 --bottleneckRate=5Mbps --csv=assignment8_results.csv"
./ns3 run "scratch/assignment8 --bottleneckRate=10Mbps --csv=assignment8_results.csv"
```
Each run appends the TCP and UDP measurements.

## Optional experiments
UDP rate:
```bash
./ns3 run "scratch/assignment8 --udpRate=500Kbps --csv=udp-rate-results.csv"
./ns3 run "scratch/assignment8 --udpRate=1Mbps --csv=udp-rate-results.csv"
./ns3 run "scratch/assignment8 --udpRate=2Mbps --csv=udp-rate-results.csv"
./ns3 run "scratch/assignment8 --udpRate=5Mbps --csv=udp-rate-results.csv"
```
Queue size:
```bash
./ns3 run "scratch/assignment8 --queuePackets=20 --csv=queue-results.csv"
./ns3 run "scratch/assignment8 --queuePackets=50 --csv=queue-results.csv"
./ns3 run "scratch/assignment8 --queuePackets=100 --csv=queue-results.csv"
```
Bottleneck delay:
```bash
./ns3 run "scratch/assignment8 --bottleneckDelay=5ms --csv=delay-results.csv"
./ns3 run "scratch/assignment8 --bottleneckDelay=10ms --csv=delay-results.csv"
./ns3 run "scratch/assignment8 --bottleneckDelay=20ms --csv=delay-results.csv"
./ns3 run "scratch/assignment8 --bottleneckDelay=50ms --csv=delay-results.csv"
```

## Run the notebook
Install Python packages if necessary:
```bash
python3 -m pip install pandas matplotlib jupyter
```
Open Jupyter:
```bash
jupyter notebook assignment8_analysis.ipynb
```
Place the CSV in the same folder as the notebook. Run all cells. The notebook uses only observed CSV data and does not fabricate values.

## TCP retransmissions
FlowMonitor does not directly expose TCP retransmission counts. Open the generated PCAP files in Wireshark and use:
`tcp.analysis.retransmission` and `tcp.analysis.fast_retransmission`.
If you record a retransmission count/rate separately, add a column to the CSV before plotting it. The notebook will plot that column if present.

## Notes
Throughput is computed as received bytes divided by the application measurement window (1 s to simulation end minus 1 s). This is a consistent measurement window for comparing runs. It is not a packet-level TCP retransmission counter.
