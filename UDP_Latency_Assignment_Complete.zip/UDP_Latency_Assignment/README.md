# UDP Traffic and Port-Based Application Delivery — NS-3

## What this program does
- Creates two nodes connected by a point-to-point link.
- Sets link data rate to 10 Mbps and queue size to 50 packets.
- Runs one UDP flow to port 5000 or two simultaneous UDP flows to ports 5000 and 6000.
- Uses a configurable per-flow UDP application payload rate (default 1 Mbps).
- Tests link delays of 2, 5, 10 and 20 ms.
- Writes PCAP captures, a CSV results file, and FlowMonitor XML output.
- Reports per-flow packet counts, throughput, packet loss, and average delay.

## Put the source into NS-3
Copy `cn_udp_latency.cc` into your NS-3 `scratch` directory:
```bash
cp cn_udp_latency.cc ~/ns-3.43/scratch/
cd ~/ns-3.43
```
Adjust the path if your NS-3 folder is different.

## Build
```bash
./ns3 build
```

## Run Experiment 1: one UDP flow
Run each command from the NS-3 root directory:
```bash
./ns3 run "scratch/cn_udp_latency --delayMs=2 --flows=1 --rateMbps=1 --csv=udp_latency_results.csv"
./ns3 run "scratch/cn_udp_latency --delayMs=5 --flows=1 --rateMbps=1 --csv=udp_latency_results.csv"
./ns3 run "scratch/cn_udp_latency --delayMs=10 --flows=1 --rateMbps=1 --csv=udp_latency_results.csv"
./ns3 run "scratch/cn_udp_latency --delayMs=20 --flows=1 --rateMbps=1 --csv=udp_latency_results.csv"
```

## Run Experiment 2: two UDP flows
```bash
./ns3 run "scratch/cn_udp_latency --delayMs=2 --flows=2 --rateMbps=1 --csv=udp_latency_results.csv"
./ns3 run "scratch/cn_udp_latency --delayMs=5 --flows=2 --rateMbps=1 --csv=udp_latency_results.csv"
./ns3 run "scratch/cn_udp_latency --delayMs=10 --flows=2 --rateMbps=1 --csv=udp_latency_results.csv"
./ns3 run "scratch/cn_udp_latency --delayMs=20 --flows=2 --rateMbps=1 --csv=udp_latency_results.csv"
```
Delete `udp_latency_results.csv` before a fresh complete run if you want a clean file:
```bash
rm -f udp_latency_results.csv
```

## Inspect PCAP
The simulation writes `udp-latency-*.pcap` files in the NS-3 root (exact naming may vary by NS-3 build).
Open them with:
```bash
wireshark udp-latency-*.pcap
```
Useful Wireshark display filters:
```text
udp
udp.dstport == 5000
udp.dstport == 6000
udp.port == 5000 || udp.port == 6000
```
Select a UDP packet and expand User Datagram Protocol. Check Destination Port. Confirm that port 5000 packets go to the first server and port 6000 packets go to the second.

## Output files
- `udp_latency_results.csv`: per-run, per-flow metrics.
- `udp-latency-*.pcap`: packet captures.
- `udp-latency-flowmon.xml`: FlowMonitor output from the last run.

CSV columns:
`delay_ms,flows,port,tx_packets,rx_packets,throughput_mbps,packet_loss_pct,avg_delay_ms`

Throughput is calculated over the configured 8-second client sending window (`1 s` to `9 s`), using FlowMonitor received bytes. Values are not pre-filled: use the actual simulation output.

## Important interpretation
Each flow offers about 1 Mbps of UDP application payload by default, and the point-to-point link is 10 Mbps. In an uncongested simulation, changing propagation delay alone is not expected to reduce a fixed-rate UDP sender's offered rate. Throughput can differ slightly due to measurement window, packet arrival timing, and losses. Do not fabricate measurements.

## Comparison table to complete from CSV
| Link delay | One-flow throughput | Two-flow port 5000 throughput | Two-flow port 6000 throughput |
|---:|---:|---:|---:|
| 2 ms | Run and record | Run and record | Run and record |
| 5 ms | Run and record | Run and record | Run and record |
| 10 ms | Run and record | Run and record | Run and record |
| 20 ms | Run and record | Run and record | Run and record |

## Troubleshooting
- If `./ns3` is not found, run commands from the NS-3 source root.
- If compilation fails, save the complete compiler error and check your exact NS-3 version/API.
- If no CSV rows appear, check that the server/client ports and FlowMonitor classifier are correct.
- If Wireshark is unavailable, install it with `sudo apt install wireshark`.
