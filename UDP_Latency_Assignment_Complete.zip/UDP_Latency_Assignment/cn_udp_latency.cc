// Assignment: UDP Traffic and Port-Based Application Delivery
// Compatible in design with the NS-3.43 API family.
// Runs one or two UDP flows over a point-to-point link and reports per-flow throughput.
// Example: ./ns3 run "scratch/cn_udp_latency --delayMs=2 --flows=2 --rateMbps=1"

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

using namespace ns3;

int main(int argc, char *argv[])
{
    double delayMs = 2.0;
    double rateMbps = 1.0;
    uint32_t flows = 1;
    std::string csvFile = "udp_latency_results.csv";

    CommandLine cmd(__FILE__);
    cmd.AddValue("delayMs", "Point-to-point link delay in milliseconds", delayMs);
    cmd.AddValue("rateMbps", "UDP application payload rate per flow in Mbps", rateMbps);
    cmd.AddValue("flows", "Number of active UDP flows (1 or 2)", flows);
    cmd.AddValue("csv", "CSV file for measured results", csvFile);
    cmd.Parse(argc, argv);

    if (!(delayMs == 2.0 || delayMs == 5.0 ||
          delayMs == 10.0 || delayMs == 20.0))
    {
        NS_FATAL_ERROR("delayMs must be 2, 5, 10, or 20");
    }
    if (flows < 1 || flows > 2)
    {
        NS_FATAL_ERROR("flows must be 1 or 2");
    }
    if (rateMbps <= 0.0)
    {
        NS_FATAL_ERROR("rateMbps must be greater than zero");
    }

    const uint32_t packetSize = 512;
    const double appStart = 1.0;
    const double appStop = 9.0;
    const double measurementSeconds = appStop - appStart;
    const double simulationStop = 10.0;

    NodeContainer nodes;
    nodes.Create(2);

    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
    p2p.SetChannelAttribute(
        "Delay", TimeValue(MilliSeconds(static_cast<uint64_t>(delayMs))));
    p2p.SetQueue("ns3::DropTailQueue<Packet>",
                 "MaxSize", QueueSizeValue(QueueSize("50p")));

    NetDeviceContainer devices = p2p.Install(nodes);

    InternetStackHelper internet;
    internet.Install(nodes);

    Ipv4AddressHelper address;
    address.SetBase("10.2.0.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = address.Assign(devices);

    // Use the assignment's requested distinct ports: 5000 and 6000.
    const uint16_t ports[2] = {5000, 6000};

    for (uint32_t i = 0; i < flows; ++i)
    {
        UdpServerHelper server(ports[i]);
        ApplicationContainer serverApps = server.Install(nodes.Get(1));
        serverApps.Start(Seconds(0.5));
        serverApps.Stop(Seconds(simulationStop));

        // Set packet interval so each flow offers approximately rateMbps of
        // UDP application payload: packetSize * 8 / rate.
        const double intervalSeconds =
            (static_cast<double>(packetSize) * 8.0) / (rateMbps * 1e6);

        UdpClientHelper client(interfaces.GetAddress(1), ports[i]);
        client.SetAttribute("PacketSize", UintegerValue(packetSize));
        client.SetAttribute("Interval", TimeValue(Seconds(intervalSeconds)));
        client.SetAttribute("MaxPackets", UintegerValue(1000000));

        ApplicationContainer clientApps = client.Install(nodes.Get(0));
        clientApps.Start(Seconds(appStart));
        clientApps.Stop(Seconds(appStop));
    }

    // PCAP is written for both point-to-point devices.
    p2p.EnablePcapAll("udp-latency");

    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> monitor = flowHelper.InstallAll();

    Simulator::Stop(Seconds(simulationStop));
    Simulator::Run();
    monitor->CheckForLostPackets();

    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(flowHelper.GetClassifier());

    // Append results. Create a header if the file is new or empty.
    bool needsHeader = true;
    {
        std::ifstream existing(csvFile);
        if (existing.good() && existing.peek() != std::ifstream::traits_type::eof())
        {
            needsHeader = false;
        }
    }

    std::ofstream csv(csvFile, std::ios::app);
    if (!csv)
    {
        NS_FATAL_ERROR("Could not open CSV output file: " << csvFile);
    }
    if (needsHeader)
    {
        csv << "delay_ms,flows,port,tx_packets,rx_packets,throughput_mbps,"
               "packet_loss_pct,avg_delay_ms\n";
    }

    std::cout << std::fixed << std::setprecision(4);
    std::cout << "\nLink delay = " << delayMs << " ms, active flows = "
              << flows << ", offered rate per flow = " << rateMbps << " Mbps\n";

    for (const auto &entry : monitor->GetFlowStats())
    {
        const Ipv4FlowClassifier::FiveTuple tuple =
            classifier->FindFlow(entry.first);
        const FlowMonitor::FlowStats &stats = entry.second;

        // Only count UDP flows addressed to one of this experiment's servers.
        if (tuple.protocol != 17 ||
            (tuple.destinationPort != 5000 && tuple.destinationPort != 6000))
        {
            continue;
        }

        // Average throughput over the configured application sending window.
        // This includes any initial arrival time and any losses in that window.
        const double throughputMbps =
            (stats.rxBytes * 8.0) / measurementSeconds / 1e6;

        const double lossPercent = stats.txPackets > 0
            ? 100.0 * static_cast<double>(stats.txPackets - stats.rxPackets)
                      / static_cast<double>(stats.txPackets)
            : 0.0;

        const double avgDelayMs = stats.rxPackets > 0
            ? 1000.0 * stats.delaySum.GetSeconds()
                      / static_cast<double>(stats.rxPackets)
            : 0.0;

        std::cout << "Destination port " << tuple.destinationPort
                  << ": TX=" << stats.txPackets
                  << ", RX=" << stats.rxPackets
                  << ", throughput=" << throughputMbps << " Mbps"
                  << ", packet loss=" << lossPercent << "%"
                  << ", average end-to-end delay=" << avgDelayMs << " ms\n";

        csv << delayMs << ','
            << flows << ','
            << tuple.destinationPort << ','
            << stats.txPackets << ','
            << stats.rxPackets << ','
            << throughputMbps << ','
            << lossPercent << ','
            << avgDelayMs << '\n';
    }

    csv.close();
    monitor->SerializeToXmlFile("udp-latency-flowmon.xml", true, true);

    Simulator::Destroy();
    return 0;
}
