// Assignment 9: Simulation and Performance Analysis of TCP Congestion Control
// NS-3.42 baseline implementation.
//
// Simulates five traffic sources (representing vehicles) sending TCP traffic
// through a shared bottleneck to a traffic-management server.
// Run one congestion-control variant per simulation: Reno or Cubic.
// IMPORTANT: Stock NS-3.42 may not provide a built-in TcpBbr model. Do not label
// a Reno/Cubic run as BBR. See README for the BBR limitation and options.

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>

using namespace ns3;

int main(int argc, char* argv[])
{
    std::string tcpType = "TcpReno";
    std::string bottleneckRate = "5Mbps";
    std::string bottleneckDelay = "20ms";
    std::string accessRate = "10Mbps";
    std::string accessDelay = "2ms";
    std::string csvFile = "assignment9_results.csv";
    std::string pcapPrefix = "assignment9";
    uint32_t vehicleCount = 5;
    uint32_t packetSize = 1200;
    uint32_t queuePackets = 100;
    double appStart = 1.0;
    double appStop = 19.0;
    double simulationTime = 20.0;

    CommandLine cmd(__FILE__);
    cmd.AddValue("tcpType", "TCP congestion control type: TcpReno or TcpCubic", tcpType);
    cmd.AddValue("bottleneckRate", "Shared bottleneck data rate", bottleneckRate);
    cmd.AddValue("bottleneckDelay", "Shared bottleneck propagation delay", bottleneckDelay);
    cmd.AddValue("accessRate", "Vehicle/server access-link rate", accessRate);
    cmd.AddValue("accessDelay", "Vehicle/server access-link delay", accessDelay);
    cmd.AddValue("vehicles", "Number of vehicle sender nodes", vehicleCount);
    cmd.AddValue("packetSize", "TCP application write size in bytes", packetSize);
    cmd.AddValue("queuePackets", "Bottleneck DropTail queue size in packets", queuePackets);
    cmd.AddValue("simulationTime", "Total simulation time in seconds", simulationTime);
    cmd.AddValue("csv", "CSV output file", csvFile);
    cmd.AddValue("pcapPrefix", "PCAP filename prefix", pcapPrefix);
    cmd.Parse(argc, argv);

    if (tcpType != "TcpReno" && tcpType != "TcpCubic")
    {
        NS_FATAL_ERROR("This NS-3.42 stock-code example supports TcpReno and TcpCubic only. "
                       "Do not select TcpBbr unless you have installed a compatible BBR model.");
    }
    if (vehicleCount < 2 || packetSize == 0 || queuePackets == 0 ||
        simulationTime <= 5.0 || appStop <= appStart)
    {
        NS_FATAL_ERROR("Invalid vehicles, packet size, queue, or simulation duration.");
    }

    // Select congestion control for all TCP sockets created by this simulation.
    // TypeId names are ns3::TcpReno and ns3::TcpCubic.
    Config::SetDefault("ns3::TcpL4Protocol::SocketType",
                       TypeIdValue(TypeId::LookupByName("ns3::" + tcpType)));

    NodeContainer vehicles;
    vehicles.Create(vehicleCount);
    Ptr<Node> roadsideRouter = CreateObject<Node>();
    Ptr<Node> trafficServer = CreateObject<Node>();

    NodeContainer allNodes;
    allNodes.Add(vehicles);
    allNodes.Add(roadsideRouter);
    allNodes.Add(trafficServer);

    InternetStackHelper internet;
    internet.Install(allNodes);

    PointToPointHelper access;
    access.SetDeviceAttribute("DataRate", StringValue(accessRate));
    access.SetChannelAttribute("Delay", StringValue(accessDelay));
    access.SetQueue("ns3::DropTailQueue<Packet>",
                    "MaxSize", QueueSizeValue(QueueSize(std::to_string(queuePackets) + "p")));

    PointToPointHelper bottleneck;
    bottleneck.SetDeviceAttribute("DataRate", StringValue(bottleneckRate));
    bottleneck.SetChannelAttribute("Delay", StringValue(bottleneckDelay));
    bottleneck.SetQueue("ns3::DropTailQueue<Packet>",
                        "MaxSize", QueueSizeValue(QueueSize(std::to_string(queuePackets) + "p")));

    // One access link per vehicle to the roadside router.
    std::vector<NetDeviceContainer> vehicleDevices;
    std::vector<Ipv4InterfaceContainer> vehicleIfaces;
    for (uint32_t i = 0; i < vehicleCount; ++i)
    {
        NetDeviceContainer link = access.Install(NodeContainer(vehicles.Get(i), roadsideRouter));
        vehicleDevices.push_back(link);
    }

    NetDeviceContainer routerServerDevices =
        bottleneck.Install(NodeContainer(roadsideRouter, trafficServer));

    Ipv4AddressHelper ip;
    for (uint32_t i = 0; i < vehicleCount; ++i)
    {
        std::ostringstream subnet;
        subnet << "10.1." << (i + 1) << ".0";
        ip.SetBase(subnet.str().c_str(), "255.255.255.0");
        vehicleIfaces.push_back(ip.Assign(vehicleDevices[i]));
    }

    ip.SetBase("10.2.0.0", "255.255.255.0");
    Ipv4InterfaceContainer routerServerIfaces = ip.Assign(routerServerDevices);
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    const uint16_t serverPort = 5000;
    PacketSinkHelper sink("ns3::TcpSocketFactory",
                          InetSocketAddress(Ipv4Address::GetAny(), serverPort));
    ApplicationContainer sinkApps = sink.Install(trafficServer);
    sinkApps.Start(Seconds(0.5));
    sinkApps.Stop(Seconds(simulationTime));

    // All vehicles send TCP BulkSend data to the common traffic server.
    for (uint32_t i = 0; i < vehicleCount; ++i)
    {
        BulkSendHelper source("ns3::TcpSocketFactory",
            InetSocketAddress(routerServerIfaces.GetAddress(1), serverPort));
        source.SetAttribute("SendSize", UintegerValue(packetSize));
        source.SetAttribute("MaxBytes", UintegerValue(0));
        ApplicationContainer sourceApps = source.Install(vehicles.Get(i));
        sourceApps.Start(Seconds(appStart));
        sourceApps.Stop(Seconds(appStop));
    }

    // PCAP captures on vehicle access links and the shared bottleneck.
    for (uint32_t i = 0; i < vehicleCount; ++i)
    {
        access.EnablePcap(pcapPrefix + "-vehicle" + std::to_string(i + 1),
                          vehicleDevices[i], true);
    }
    bottleneck.EnablePcap(pcapPrefix + "-bottleneck", routerServerDevices, true);

    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> monitor = flowHelper.InstallAll();
    Simulator::Stop(Seconds(simulationTime));
    Simulator::Run();
    monitor->CheckForLostPackets();

    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(flowHelper.GetClassifier());

    bool headerNeeded = true;
    {
        std::ifstream in(csvFile);
        if (in.good() && in.peek() != std::ifstream::traits_type::eof())
            headerNeeded = false;
    }
    std::ofstream csv(csvFile, std::ios::app);
    if (!csv) NS_FATAL_ERROR("Could not open CSV file: " << csvFile);
    if (headerNeeded)
    {
        csv << "tcp_type,bottleneck_rate,bottleneck_delay,queue_packets,vehicle_count,"
               "source_ip,destination_ip,source_port,destination_port,tx_packets,"
               "rx_packets,tx_bytes,rx_bytes,throughput_mbps,packet_loss_pct,avg_delay_ms\n";
    }

    const double measurementWindow = appStop - appStart;
    std::cout << std::fixed << std::setprecision(4)
              << "\nTCP type: " << tcpType
              << ", bottleneck: " << bottleneckRate
              << ", bottleneck delay: " << bottleneckDelay
              << ", vehicles: " << vehicleCount << "\n";

    for (const auto& item : monitor->GetFlowStats())
    {
        Ipv4FlowClassifier::FiveTuple tuple = classifier->FindFlow(item.first);
        const FlowMonitor::FlowStats& s = item.second;
        if (tuple.protocol != 6 || tuple.destinationPort != serverPort)
            continue;

        double throughputMbps = static_cast<double>(s.rxBytes) * 8.0 /
                                measurementWindow / 1e6;
        double lossPct = s.txPackets > 0
            ? 100.0 * static_cast<double>(s.txPackets - s.rxPackets) /
                      static_cast<double>(s.txPackets) : 0.0;
        double avgDelayMs = s.rxPackets > 0
            ? 1000.0 * s.delaySum.GetSeconds() / static_cast<double>(s.rxPackets)
            : 0.0;

        std::cout << "Vehicle flow " << tuple.sourceAddress
                  << " -> " << tuple.destinationAddress
                  << ": TX=" << s.txPackets << ", RX=" << s.rxPackets
                  << ", throughput=" << throughputMbps << " Mbps"
                  << ", loss=" << lossPct << "%"
                  << ", average delay=" << avgDelayMs << " ms\n";

        csv << tcpType << ',' << bottleneckRate << ',' << bottleneckDelay << ','
            << queuePackets << ',' << vehicleCount << ','
            << tuple.sourceAddress << ',' << tuple.destinationAddress << ','
            << tuple.sourcePort << ',' << tuple.destinationPort << ','
            << s.txPackets << ',' << s.rxPackets << ',' << s.txBytes << ','
            << s.rxBytes << ',' << throughputMbps << ',' << lossPct << ','
            << avgDelayMs << '\n';
    }
    csv.close();
    monitor->SerializeToXmlFile("assignment9-flowmon.xml", true, true);

    std::cout << "CSV: " << csvFile
              << "\nFlowMonitor XML: assignment9-flowmon.xml"
              << "\nPCAP prefix: " << pcapPrefix
              << "\nNote: congestion-window and retransmission measurements need TCP trace/PCAP analysis.\n";

    Simulator::Destroy();
    return 0;
}
