# Assignment 9 — TCP Congestion Control in an Intelligent Transportation System (VANET-style)

## What the assignment asks
The PDF asks you to simulate vehicles sending traffic data to a traffic management server through a roadside router, and compare TCP Reno, TCP Cubic and TCP BBR for throughput, delay, packet loss, fairness and congestion window. It also asks why low delay and reliable communication matter in intelligent transportation.

## NS-3.42 compatibility and BBR limitation
This project is written against the NS-3.42 API for the built-in `TcpReno` and `TcpCubic` models. **Do not claim the BBR case is simulated by this code.** Stock NS-3.42 distributions may not include a built-in `TcpBbr` congestion-control implementation. If `ns3::TcpBbr` is not registered in your build, it cannot be selected merely by changing a string. To complete a genuine BBR comparison, use a BBR module compatible with your exact NS-3 release or a newer NS-3 version that actually provides the model, then validate it with a build and a known test.

## Topology
Five vehicle sender nodes connect to one roadside router using access links. The roadside router connects over a shared bottleneck link to the traffic-management server. Each vehicle uses a TCP BulkSend application; the server uses PacketSink. All vehicle flows share one congestion-control algorithm per run.

## Build in NS-3.42
Copy the source into your NS-3.42 `scratch/` folder:
```bash
cp assignment9.cc ~/ns-3.42/scratch/
cd ~/ns-3.42
./ns3 build
```
Adjust the directory if NS-3 is installed elsewhere.

## Run TCP Reno and Cubic
```bash
rm -f assignment9_results.csv
./ns3 run "scratch/assignment9 --tcpType=TcpReno --bottleneckRate=2Mbps --csv=assignment9_results.csv"
./ns3 run "scratch/assignment9 --tcpType=TcpReno --bottleneckRate=5Mbps --csv=assignment9_results.csv"
./ns3 run "scratch/assignment9 --tcpType=TcpReno --bottleneckRate=10Mbps --csv=assignment9_results.csv"
./ns3 run "scratch/assignment9 --tcpType=TcpCubic --bottleneckRate=2Mbps --csv=assignment9_results.csv"
./ns3 run "scratch/assignment9 --tcpType=TcpCubic --bottleneckRate=5Mbps --csv=assignment9_results.csv"
./ns3 run "scratch/assignment9 --tcpType=TcpCubic --bottleneckRate=10Mbps --csv=assignment9_results.csv"
```
The CSV contains a row per vehicle flow, not fabricated values. It records throughput, packet loss, and average delay.

## Optional parameter sweeps
Bottleneck delay:
```bash
./ns3 run "scratch/assignment9 --tcpType=TcpReno --bottleneckDelay=5ms --csv=delay-results.csv"
./ns3 run "scratch/assignment9 --tcpType=TcpReno --bottleneckDelay=20ms --csv=delay-results.csv"
./ns3 run "scratch/assignment9 --tcpType=TcpReno --bottleneckDelay=50ms --csv=delay-results.csv"
```
Queue:
```bash
./ns3 run "scratch/assignment9 --tcpType=TcpReno --queuePackets=20 --csv=queue-results.csv"
./ns3 run "scratch/assignment9 --tcpType=TcpReno --queuePackets=100 --csv=queue-results.csv"
```

## Notebook and plots
Install:
```bash
python3 -m pip install pandas matplotlib jupyter
jupyter notebook assignment9_analysis.ipynb
```
Place `assignment9_results.csv` next to the notebook and run all cells. It plots throughput, delay and loss; fairness is computed using Jain's fairness index across vehicle flows for each run. Congestion-window and retransmission plots require separate instrumentation/PCAP data and are only plotted if the corresponding data file/columns are supplied.

## TCP retransmissions and congestion window
FlowMonitor does not directly expose TCP retransmission counts or congestion-window time series. Use TCP PCAP analysis for retransmissions (Wireshark filters `tcp.analysis.retransmission` and `tcp.analysis.fast_retransmission`). For congestion window, instrument the TCP socket's `CongestionWindow` trace source in NS-3, or use a documented tracing helper supported by your exact build. Do not present FlowMonitor metrics as congestion-window or retransmission measurements.

## Fairness
Jain's fairness index across N vehicle-flow throughput values is:
`J = (sum(x_i)^2) / (N * sum(x_i^2))`
where `x_i` is each vehicle flow's measured throughput. Values closer to 1 indicate more equal throughput allocation. This is computed per TCP algorithm and bottleneck configuration.

## Interpretation
- TCP Reno generally uses loss-based congestion control and additive increase / multiplicative decrease.
- TCP Cubic uses a cubic congestion-window growth function and is designed for high-bandwidth/high-delay paths.
- BBR estimates bottleneck bandwidth and round-trip propagation time rather than relying solely on packet loss to determine sending rate. This is conceptual background only unless an actual BBR implementation is installed and run.
- In ITS/VANET scenarios, low delay matters for timely collision warnings, emergency braking, traffic-signal coordination and hazard updates. Reliability matters because missing or late messages can produce unsafe decisions. The experiment here models TCP over a wired bottleneck and represents vehicles as traffic sources; it does not simulate wireless VANET mobility, radio propagation, or IEEE 802.11p/802.11bd.

## CSV columns
`tcp_type,bottleneck_rate,bottleneck_delay,queue_packets,vehicle_count,source_ip,destination_ip,source_port,destination_port,tx_packets,rx_packets,tx_bytes,rx_bytes,throughput_mbps,packet_loss_pct,avg_delay_ms`
