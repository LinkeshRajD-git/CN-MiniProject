# Assignment 2 — Multi-Client Student Lookup using TCP and UDP

## Requirements
- Ubuntu/Linux with GCC and POSIX threads.
- `students.csv` in the current working directory of each server.
- TCP server: port 5000; UDP server: port 5001.
- Clients default to `127.0.0.1`. For two computers, change `SERVER_IP` in the relevant client to the server's LAN IP.

## CSV format
The first row is a header. Each following row must contain:
`roll_number,name,department,semester,cgpa`
For this simple lab parser, fields must not contain commas.

## Compile
Run these commands in this directory:
```bash
gcc -Wall -Wextra -pthread tcp_server.c -o tcp_server
gcc -Wall -Wextra tcp_client.c -o tcp_client
gcc -Wall -Wextra udp_server.c -o udp_server
gcc -Wall -Wextra udp_client.c -o udp_client
```

## Run TCP
Terminal 1:
```bash
./tcp_server
```
Terminal 2:
```bash
./tcp_client
```
Try `23CS001` and then `99CS999`. The TCP server creates a detached POSIX thread for each accepted client.

## Run UDP
Terminal 3:
```bash
./udp_server
```
Terminal 4:
```bash
./udp_client
```
Try `23CS002` and then `99CS999`. UDP uses one datagram for the request and one for the reply. The client has a 5-second receive timeout.

## Expected examples
TCP, input `23CS001`:
```
--- Student Academic Profile ---
Roll Number: 23CS001
Name: Arun Kumar
Department: CSE
Semester: 4
CGPA: 8.45
```
UDP, input `23CS002`:
```
--- Student Record Verification ---
Roll Number: 23CS002
Student Name: Meena Ravi
```
For an unknown roll number, both applications return:
`Student Record Not Found`

## TCP vs UDP comparison
| Feature | TCP | UDP |
|---|---|---|
| Connection | Connection-oriented; establishes a connection before data transfer | Connectionless; sends datagrams without a connection handshake |
| Reliability | Reliable, ordered byte stream with retransmission by the transport protocol | Best effort; datagrams or replies can be lost |
| Ordering | Preserves byte order | Does not guarantee datagram order |
| Error recovery | TCP detects loss and retransmits; application should still handle connection errors | No built-in retransmission; this client reports a timeout, but does not retry |
| Communication | Stream; this implementation uses newline framing for the request and reads until server closes the response | Message/datagram-based; each request and response is a datagram |

## Notes
- This lab server is for localhost/lab-network demonstrations, not production use.
- For remote clients, open the relevant port in the firewall and set `SERVER_IP` to the server's LAN address.
- The sample data is fictional. Replace it with permitted lab data if required.
