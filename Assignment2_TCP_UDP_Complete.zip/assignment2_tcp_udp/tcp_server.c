#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define TCP_PORT 5000
#define BACKLOG 10
#define CSV_FILE "students.csv"
#define LINE_SIZE 512

typedef struct {
    int client_fd;
} ClientArgs;

typedef struct {
    char roll[32];
    char name[128];
    char department[64];
    char semester[16];
    char cgpa[16];
} Student;

/* CSV fields are expected not to contain commas. */
static int find_student(const char *wanted_roll, Student *result) {
    FILE *fp = fopen(CSV_FILE, "r");
    if (!fp) {
        perror("Could not open students.csv");
        return -1;
    }

    char line[LINE_SIZE];
    int first_line = 1;
    while (fgets(line, sizeof(line), fp)) {
        if (first_line) { /* skip CSV header */
            first_line = 0;
            continue;
        }

        Student s = {0};
        char *newline = strpbrk(line, "\r\n");
        if (newline) *newline = '\0';

        int fields = sscanf(line, "%31[^,],%127[^,],%63[^,],%15[^,],%15[^\n]",
                            s.roll, s.name, s.department, s.semester, s.cgpa);
        if (fields == 5 && strcmp(s.roll, wanted_roll) == 0) {
            *result = s;
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

/* Read one newline-terminated roll number; TCP does not preserve message boundaries. */
static int read_line(int fd, char *buffer, size_t capacity) {
    size_t used = 0;
    while (used + 1 < capacity) {
        char ch;
        ssize_t n = recv(fd, &ch, 1, 0);
        if (n == 0) break;
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (ch == '\n') break;
        if (ch != '\r') buffer[used++] = ch;
    }
    buffer[used] = '\0';
    return (int)used;
}

static int send_all(int fd, const char *data) {
    size_t total = strlen(data), sent = 0;
    while (sent < total) {
        ssize_t n = send(fd, data + sent, total - sent, 0);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        sent += (size_t)n;
    }
    return 0;
}

static void *handle_client(void *arg) {
    ClientArgs *args = (ClientArgs *)arg;
    int client_fd = args->client_fd;
    free(args);

    char roll[64];
    int n = read_line(client_fd, roll, sizeof(roll));
    if (n > 0) {
        Student s;
        int found = find_student(roll, &s);
        char response[LINE_SIZE];

        if (found == 1) {
            snprintf(response, sizeof(response),
                     "Roll Number: %s\nName: %s\nDepartment: %s\nSemester: %s\nCGPA: %s\n",
                     s.roll, s.name, s.department, s.semester, s.cgpa);
        } else if (found == 0) {
            snprintf(response, sizeof(response), "Student Record Not Found\n");
        } else {
            snprintf(response, sizeof(response),
                     "Server Error: Unable to read students.csv\n");
        }
        send_all(client_fd, response);
    }

    shutdown(client_fd, SHUT_RDWR);
    close(client_fd);
    return NULL;
}

int main(void) {
    signal(SIGPIPE, SIG_IGN);

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) { perror("socket"); return EXIT_FAILURE; }

    int reuse = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(TCP_PORT);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind"); close(server_fd); return EXIT_FAILURE;
    }
    if (listen(server_fd, BACKLOG) < 0) {
        perror("listen"); close(server_fd); return EXIT_FAILURE;
    }

    printf("TCP student server listening on port %d\n", TCP_PORT);
    printf("Keep %s in the current working directory.\n", CSV_FILE);

    for (;;) {
        struct sockaddr_in client_addr;
        socklen_t addr_len = sizeof(client_addr);
        int client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len);
        if (client_fd < 0) {
            if (errno == EINTR) continue;
            perror("accept");
            continue;
        }

        ClientArgs *args = malloc(sizeof(*args));
        if (!args) {
            perror("malloc"); close(client_fd); continue;
        }
        args->client_fd = client_fd;

        pthread_t thread;
        int err = pthread_create(&thread, NULL, handle_client, args);
        if (err != 0) {
            fprintf(stderr, "pthread_create: %s\n", strerror(err));
            close(client_fd);
            free(args);
            continue;
        }
        pthread_detach(thread);
    }

    close(server_fd);
    return 0;
}
