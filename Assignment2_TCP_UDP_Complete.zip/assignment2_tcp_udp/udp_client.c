#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#define SERVER_IP "127.0.0.1"
#define UDP_PORT 5001

int main(void) {
    char roll[64];
    printf("Enter Roll Number: ");
    if (!fgets(roll, sizeof(roll), stdin)) return EXIT_FAILURE;
    roll[strcspn(roll, "\r\n")] = '\0';

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) { perror("socket"); return EXIT_FAILURE; }

    /* Prevent the client from waiting forever if the response is lost. */
    struct timeval timeout = {5, 0};
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(UDP_PORT);
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) != 1) {
        fprintf(stderr, "Invalid server IP address\n"); close(sock); return EXIT_FAILURE;
    }

    ssize_t sent = sendto(sock, roll, strlen(roll), 0,
                          (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (sent < 0) { perror("sendto"); close(sock); return EXIT_FAILURE; }

    char response[512];
    struct sockaddr_in from_addr;
    socklen_t from_len = sizeof(from_addr);
    ssize_t n = recvfrom(sock, response, sizeof(response) - 1, 0,
                         (struct sockaddr *)&from_addr, &from_len);
    if (n < 0) {
        perror("recvfrom (server stopped, or response timed out)");
        close(sock);
        return EXIT_FAILURE;
    }

    response[n] = '\0';
    printf("\n--- Student Record Verification ---\n%s", response);

    close(sock);
    return 0;
}
