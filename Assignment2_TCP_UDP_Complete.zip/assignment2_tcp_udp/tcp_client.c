#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define SERVER_IP "127.0.0.1"
#define TCP_PORT 5000

int main(void) {
    char roll[64];
    printf("Enter Roll Number: ");
    if (!fgets(roll, sizeof(roll), stdin)) return EXIT_FAILURE;
    roll[strcspn(roll, "\r\n")] = '\0';

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) { perror("socket"); return EXIT_FAILURE; }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(TCP_PORT);
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) != 1) {
        fprintf(stderr, "Invalid server IP address\n"); close(sock); return EXIT_FAILURE;
    }

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect (is tcp_server running?)"); close(sock); return EXIT_FAILURE;
    }

    if (send(sock, roll, strlen(roll), 0) < 0 ||
        send(sock, "\n", 1, 0) < 0) {
        perror("send"); close(sock); return EXIT_FAILURE;
    }
    shutdown(sock, SHUT_WR);

    printf("\n--- Student Academic Profile ---\n");
    char buffer[512];
    for (;;) {
        ssize_t n = recv(sock, buffer, sizeof(buffer) - 1, 0);
        if (n == 0) break;
        if (n < 0) {
            if (errno == EINTR) continue;
            perror("recv"); close(sock); return EXIT_FAILURE;
        }
        buffer[n] = '\0';
        fputs(buffer, stdout);
    }

    close(sock);
    return 0;
}
