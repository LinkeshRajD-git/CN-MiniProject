#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define UDP_PORT 5001
#define CSV_FILE "students.csv"
#define LINE_SIZE 512

typedef struct {
    char roll[32];
    char name[128];
    char department[64];
    char semester[16];
    char cgpa[16];
} Student;

/* CSV fields are expected not to contain commas. */
static int find_student(const char *wanted_roll, Student *result) {
    FILE *fp = fopen(CSV_FILE, "r");
    if (!fp) {
        perror("Could not open students.csv");
        return -1;
    }

    char line[LINE_SIZE];
    int first_line = 1;
    while (fgets(line, sizeof(line), fp)) {
        if (first_line) { first_line = 0; continue; }

        Student s = {0};
        char *newline = strpbrk(line, "\r\n");
        if (newline) *newline = '\0';

        int fields = sscanf(line, "%31[^,],%127[^,],%63[^,],%15[^,],%15[^\n]",
                            s.roll, s.name, s.department, s.semester, s.cgpa);
        if (fields == 5 && strcmp(s.roll, wanted_roll) == 0) {
            *result = s;
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int main(void) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) { perror("socket"); return EXIT_FAILURE; }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(UDP_PORT);

    if (bind(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind"); close(sock); return EXIT_FAILURE;
    }

    printf("UDP student server listening on port %d\n", UDP_PORT);
    printf("Keep %s in the current working directory.\n", CSV_FILE);

    for (;;) {
        char roll[64];
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        ssize_t n = recvfrom(sock, roll, sizeof(roll) - 1, 0,
                             (struct sockaddr *)&client_addr, &client_len);
        if (n < 0) { perror("recvfrom"); continue; }
        roll[n] = '\0';
        roll[strcspn(roll, "\r\n")] = '\0';

        Student s;
        char response[256];
        int found = find_student(roll, &s);
        if (found == 1) {
            snprintf(response, sizeof(response),
                     "Roll Number: %s\nStudent Name: %s\n", s.roll, s.name);
        } else if (found == 0) {
            snprintf(response, sizeof(response), "Student Record Not Found\n");
        } else {
            snprintf(response, sizeof(response),
                     "Server Error: Unable to read students.csv\n");
        }

        if (sendto(sock, response, strlen(response), 0,
                   (struct sockaddr *)&client_addr, client_len) < 0) {
            perror("sendto");
        }
    }

    close(sock);
    return 0;
}
